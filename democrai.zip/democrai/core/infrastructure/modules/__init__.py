"""Module runtime adapters."""
