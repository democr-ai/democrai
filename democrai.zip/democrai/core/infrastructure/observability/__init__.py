"""Observability adapters (logging/metrics)."""
